import React, { useEffect, useState } from 'react';
import { listAccessPoints, deleteAccessPoint } from '../../../services/accessPointService';
import { useNavigate } from 'react-router-dom';

const AccessPointList = () => {
  const [aps, setAps] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    listAccessPoints().then(res => setAps(res.data));
  }, []);

  const handleDelete = async (id) => {
    await deleteAccessPoint(id);
    setAps(aps.filter(ap => ap.access_id !== id));
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-700">Access Points</h2>
        <button
          onClick={() => navigate('admin/accesspoints/create')}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          + Add New
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full bg-white shadow-md rounded">
          <thead>
            <tr className="bg-gray-200 text-gray-700">
              <th className="py-2 px-4 text-left">Path</th>
              <th className="py-2 px-4 text-left">Method</th>
              <th className="py-2 px-4 text-left">Module</th>
              <th className="py-2 px-4 text-left">Public</th>
              <th className="py-2 px-4 text-left">Permission</th>
              <th className="py-2 px-4 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {aps.map(ap => (
              <tr key={ap.access_id} className="border-b hover:bg-gray-50">
                <td className="py-2 px-4">{ap.endpoint_path}</td>
                <td className="py-2 px-4">{ap.method}</td>
                <td className="py-2 px-4">{ap.module}</td>
                <td className="py-2 px-4">{ap.is_public ? 'Yes' : 'No'}</td>
                <td className="py-2 px-4">{ap.permission_code || 'N/A'}</td>
                <td className="py-2 px-4 space-x-2">
                  <button
                    onClick={() => navigate(`/admin/accesspoints/${ap.access_id}`)}
                    className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600"
                  >
                    View
                  </button>
                  <button
                    onClick={() => navigate(`admin/accesspoints/edit/${ap.access_id}`)}
                    className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(ap.access_id)}
                    className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {aps.length === 0 && (
              <tr>
                <td colSpan="6" className="text-center py-4 text-gray-500">
                  No access points found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AccessPointList;
